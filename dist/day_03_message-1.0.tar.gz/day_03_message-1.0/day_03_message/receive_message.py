def receive():
    return "收到信息"

